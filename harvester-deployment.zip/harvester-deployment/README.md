# SUSE Harvester & Rancher Prime — Automated Bare-Metal Deployment

Ansible automation that installs a **3-node SUSE Harvester HCI cluster on bare metal via PXE boot** and then deploys a highly available **Rancher Prime management cluster** (3 × RKE2 VMs, built with the SUSE Edge Image Builder) on top of it — fully unattended.

```
┌─────────────────────────────────────────────────────────────────┐
│  Admin / PXE host (openSUSE Leap 15.6)                          │
│  dnsmasq · TFTP · nginx · NFS · Edge Image Builder · Ansible    │
└───────────────┬─────────────────────────────────────────────────┘
                │ PXE boot + automated install
┌───────────────▼─────────────────────────────────────────────────┐
│  Harvester HCI cluster (3 bare-metal nodes, VIP)                │
│  Longhorn storage · cluster networks · VM images                │
│   ┌──────────────────────────────────────────────┐              │
│   │  Rancher Prime cluster (3 RKE2 VMs, LB VIP)  │              │
│   │  cert-manager · Rancher · Harvester plugin   │              │
│   └──────────────────────────────────────────────┘              │
└─────────────────────────────────────────────────────────────────┘
```

## Features

- Fully automated PXE server setup (dnsmasq proxy DHCP, TFTP, iPXE, nginx)
- Per-node iPXE scripts and Harvester install configs, selected by MAC address
- VLAN and non-VLAN deployments, Harvester ≥ 1.7 and < 1.7 supported
- Custom self-installing Rancher image built with the SUSE Edge Image Builder
- Post-install configuration of Harvester (storage classes, networks, backup target, images) and Rancher (UI plugin, cluster import) — everything via the Kubernetes API
- Idempotent: every playbook can be re-run safely

## Requirements

| Component | Requirement |
|---|---|
| Admin host | openSUSE Leap 15.6, ≥ 2 vCPU, ≥ 8 GB RAM, ≥ 120 GB free disk |
| Harvester nodes | 3 × bare metal, PXE-bootable NIC, known MAC addresses |
| Ansible | ≥ 2.14 with `community.general` and `kubernetes.core` |
| Network | One L2 segment shared by admin host and nodes; free IPs for nodes + 2 VIPs |
| Licenses | SUSE Customer Center registration code (SL Micro), Rancher Prime access |

```bash
ansible-galaxy collection install -r requirements.yml
```

## Configuration

All environment-specific values live in `vars/` — search for **`CHANGE_ME`** and adjust:

| File | Contents |
|---|---|
| `vars/network.yml` | Subnet, gateway, DNS, VIPs, node IPs, VLANs |
| `vars/infrastructure.yml` | Versions, node names, MAC addresses, credentials (placeholders), TLS paths |
| `vars/general.yml` | Packages, directory layout, image list |

### 🔐 Secrets

This repository ships **without any real credentials**. Before running:

1. Replace every `CHANGE_ME` (tokens, passwords, SCC code, SSH public key).
2. Generate the encrypted OS password: `openssl passwd -6 'YourPassword'`
3. Place `tls.crt`, `tls.key` and `cacerts.pem` in `./cert/` (see `cert/README.md`).
4. Preferably encrypt secrets with **Ansible Vault**:
   `ansible-vault encrypt_string 'MySecret' --name 'harvester_cluster_token'`

Kubeconfigs (`harvester_kubeconfig.yaml`, `rancher_kubeconfig.yaml`), certificates and keys are excluded from Git via `.gitignore`. Example structures are provided as `*.example` files.

## Deployment workflow

| # | Playbook | Purpose |
|---|---|---|
| 01 | `01-playbook-prepare.yaml` | Turn the admin host into a PXE server, download all artifacts, install kubectl |
| 02 | `02-playbook-edge-image-builder.yaml` | Build the self-installing Rancher ISO with the Edge Image Builder |
| 04 | `04-playbook-nfs-server.yaml` | Provide an NFS export as the Harvester backup target |
| 11 | `11-playbook-pxe-onsite-validate-setup.yaml` | Validate the PXE setup on site (services, files, HTTP access) |
| — | *Power on the bare-metal nodes* | Node 1 creates the cluster, nodes 2 + 3 join automatically |
| 12 | `12-playbook-harvester-config.yaml` | Configure Harvester: SSH key, backup target, disks, storage class, images, networks |
| 13 | `13-playbook-rancher.yaml` | Create the 3 Rancher VMs, IP pool and load balancer on Harvester |
| 15 | `15-playbook-rancher-config.yaml` | Install the Harvester UI plugin and import Harvester into Rancher |

```bash
ansible-playbook 01-playbook-prepare.yaml
ansible-playbook 02-playbook-edge-image-builder.yaml
ansible-playbook 04-playbook-nfs-server.yaml
ansible-playbook 11-playbook-pxe-onsite-validate-setup.yaml
# → power on the Harvester nodes, wait for the installation to finish
#   download the kubeconfig from the Harvester UI → ./harvester_kubeconfig.yaml
ansible-playbook 12-playbook-harvester-config.yaml
ansible-playbook 13-playbook-rancher.yaml
#   download the kubeconfig from the Rancher UI → ./rancher_kubeconfig.yaml
ansible-playbook 15-playbook-rancher-config.yaml
```

## Repository layout

```
.
├── 01-playbook-prepare.yaml                 # PXE server setup
├── 02-playbook-edge-image-builder.yaml      # Rancher image build (EIB)
├── 04-playbook-nfs-server.yaml              # NFS backup target
├── 11-playbook-pxe-onsite-validate-setup.yaml
├── 12-playbook-harvester-config.yaml        # Harvester base config
├── 13-playbook-rancher.yaml                 # Rancher VMs + LB
├── 15-playbook-rancher-config.yaml          # Rancher config + import
├── requirements.yml                         # Ansible collections
├── vars/                                    # ← all environment settings
├── cert/                                    # TLS material (Git-ignored)
├── *.kubeconfig.yaml.example                # kubeconfig templates
└── roles/
    ├── pxe_*                                # PXE server / boot artifacts
    ├── eib_*                                # Edge Image Builder tree
    ├── harvester_*                          # Harvester API configuration
    └── rancher_*                            # Rancher API configuration
```

Every role and template carries an English header comment explaining what it does and why.

## Troubleshooting

- **Node does not PXE boot** — run playbook 11; check `journalctl -u dnsmasq -f` on the admin host and verify the node's MAC address in `vars/infrastructure.yml`.
- **Harvester install hangs** — open the node console; the config URL printed by iPXE must be reachable (`curl http://<pxe_ip>/harvester/boot.ipxe`).
- **Image upload stays at 0 %** — the URL in the `VirtualMachineImage` points at the admin host; nginx must still be running (start it via playbook 11 or role `pxe_onsite_on`).
- **Rancher VMs get no IP** — MAC addresses of the VMs (playbook 13 / `vars/infrastructure.yml`) must match the EIB network configs (playbook 02) exactly.
- Inspect Harvester settings: `kubectl get settings -n harvester --kubeconfig ./harvester_kubeconfig.yaml`

## License

Apache-2.0 (adjust as needed). SUSE, Harvester, Rancher and SLE Micro are trademarks of SUSE LLC.
