# TLS certificates

Place the following files in this directory before running
`02-playbook-edge-image-builder.yaml`:

| File | Purpose |
|---|---|
| `tls.crt` | Server certificate for the Rancher ingress (FQDN = `rke2_hostname`) |
| `tls.key` | Private key belonging to `tls.crt` |
| `cacerts.pem` | Root CA certificate (private CA) |

These files are **excluded from Git** via `.gitignore` — never commit
certificates or private keys.
